var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var ContactSchema = new Schema({
    fullnameContact: {
        type: String,
        required: true
    },
    lastnameContact:{
        type: String,
        default: ""
    },
    email:{
        type: String,
        required: true,
    },
    mobile: {
        type: Number,
        default: 0,
    },
    dob: {
        type: Date,
        default: Date.now,
    },
    accountId:{
        type: Schema.Types.ObjectId,
    }
});

module.exports = mongoose.model('Contact', ContactSchema);