var mongoose = require('mongoose');

var Schema = mongoose.Schema;

// noinspection JSAnnotator
var AccountSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    website:{
        type: String,
        default: ""
    },
    phone:{
        type: Number,
        default: 0,
    },
    UserId:{
        type: Schema.Types.ObjectId,
    }
});

module.exports = mongoose.model('Account', AccountSchema);