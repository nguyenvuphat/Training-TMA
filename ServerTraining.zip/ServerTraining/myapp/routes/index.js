global.router = require('express').Router();
var router = global.router;

router = require('../routes/accounts');
router = require('../routes/users');
router = require('../routes/contacts');
router = require('../routes/roles');

router.get('/', function(req, res, next) {
    res.render('index', { title: 'Express' });
});

module.exports = router;
