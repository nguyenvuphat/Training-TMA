var router = global.router;

var moongose = require('mongoose');
let roles = require('../models/RoleModel');

router.get('/listRole', (req, res, next) =>{
    roles.find({}).limit(100).sort({name: 1}).select({
        name: 1,
    }).exec((err, role) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: role,
                count: role.length,
                message: "Query list Role Successfully"
            })
        }
    });
});

router.get('/getrolebyid', (req, res, next) => {
    roles.findById(moongose.Types.ObjectId(req.query.role_id),
        (err, role) => {
            if(!role)
            {
                res.json({
                    result: "failed",
                    data: {},
                    message: `Error is ${err}`
                });
            }
            else{
                res.json({
                    result: "Ok",
                    data: role,
                    message: "Query A Role Successfully"
                })
            }
        }
    );
});

router.post('/insertRole', (req, res, next) => {
    var newRole = new roles({
        name: req.body.name,
    });

    newRole.save((err, addRole) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`,
            });
        }
        else{
            res.json({
                result: "Ok",
                data: addRole,
                message: "Insert new Role Successfully",
            });
        }
    });
});

router.put('/updaterole', (req, res, next) => {
    let conditions = {};
    if(moongose.Types.ObjectId.isValid(req.body.role_id) == true)
    {
        conditions._id = moongose.Types.ObjectId(req.body.role_id);
    }
    else{
        res.json({
            result: "failed",
            data: {},
            message: "You must enter a role id to update",
        });
    }
    let newvalue = {};

    newvalue.name = req.body.name;

    const options = {
        new: true,
    }

    roles.findOneAndUpdate(conditions, {$set: newvalue}, options, (err, updateRole) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: updateRole,
                message: "Update Role successfully",
            });
        }
    });
});

router.delete('/deleterole', (req, res, next) => {
    roles.findOneAndRemove({_id: req.body.role_id}, (err, removeRole) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`,
            });
            return;
        }
        res.json({
            result: "Ok",
            data: removeRole,
            message: 'Delete Role Successfully',
        });
    });
});

module.exports = router;