var router = global.router;

var moongose = require('mongoose');
let accounts = require('../models/AccountModel');

router.get('/listAccount', (req, res, next) =>{
    accounts.find({}).limit(100).sort({name: 1}).select({
        name: 1,
        website: 1,
        phone: 1,
        UserId: 1,
    }).exec((err, account) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: account,
                count: account.length,
                message: "Query list Account Successfully"
            })
        }
    });
});

router.get('/getaccountbyid', (req, res, next) => {
    accounts.findById(moongose.Types.ObjectId(req.query.account_id),
        (err, account) => {
            if(!account)
            {
                res.json({
                    result: "failed",
                    data: {},
                    message: `Error is ${err}`
                });
            }
            else{
                res.json({
                    result: "Ok",
                    data: account,
                    message: "Query A Account Successfully"
                })
            }
        }
    );
});

router.post('/insertAccount', (req, res, next) => {
    const criteria = {
        name: req.body.name,
    }
    accounts.find(criteria).limit(1).exec((err, account) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`,
            });
        }
        else{
            if(account.length > 0)
            {
                res.json({
                    result: "failed",
                    data: {},
                    message: "Can not insert because this account exists",
                });
            }
            else{
                var newAccount = new accounts({
                    name: req.body.name,
                    website: req.body.website,
                    phone: req.body.phone,
                });
                newAccount.save((err, addAccount) => {
                    if(err)
                    {
                        res.json({
                            result: "failed",
                            data: {},
                            message: `Error is ${err}`,
                        });
                    }
                    else{
                        res.json({
                            result: "Ok",
                            data: addAccount,
                            message: "Insert new Account Successfully",
                        });
                    }
                });
            }
        }
    });
});

router.put('/updateaccount', (req, res, next) => {
    let conditions = {};
    if(moongose.Types.ObjectId.isValid(req.body.account_id) == true)
    {
        conditions._id = moongose.Types.ObjectId(req.body.account_id);
    }
    else{
        res.json({
            result: "failed",
            data: {},
            message: "You must enter a account id to update",
        });
    }
    let newvalue = {};
    newvalue.name = req.body.name;
    newvalue.website = req.body.website,
    newvalue.phone = req.body.phone,
    newvalue.UserId = req.body.user_id;
    const options = {
        new: true,
    }

    accounts.findOneAndUpdate(conditions, {$set: newvalue}, options, (err, updateAccount) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: updateAccount,
                message: "Update Account successfully",
            });
        }
    });

});

router.delete('/deleteaccount', (req, res, next) => {
    accounts.findOneAndRemove({_id: req.body.account_id}, (err, removeAccount) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`,
            });
            return;
        }
        res.json({
            result: "Ok",
            data: removeAccount,
            message: 'Delete Account Successfully',
        });
    });
});


module.exports = router;