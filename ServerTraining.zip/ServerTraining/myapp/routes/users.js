var router = global.router;

var moongose = require('mongoose');
let users = require('../models/UserModel');

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport('smtps://nguyenvuphattdt@gmail.com:trucphuong@smtp.gmail.com');

router.post('/mail', (req, res, next) => {
    let username = req.body.username;
    let email = req.body.email;
    let password = req.body.password;

    let mailOption = {
        from: username,
        to: email,
        subject: 'Active User',
        html: '<p>You have got a new message</b><ul><li>Username:' + username + '</li><li>Email:' + email + '</li><li>Password:' + password + '</li></ul>'
    };

    transporter.sendMail(mailOption, (err, info) => {
        if(err)
        {
            res.json({ message: 'send mail failed' + err});
        }
        else{
            res.json({message: 'Send mail: ' + info.response});
        }
    });
});

router.get('/listUser', (req, res, next) =>{
    users.find({}).limit(100).sort({name: 1}).select({
        name: 1,
        email: 1,
        password: 1,
        accountId: 1,
    }).exec((err, user) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: user,
                count: user.length,
                message: "Query list User Successfully"
            })
        }
    });
});

router.get('/getuserbyid', (req, res, next) => {
    users.findById(moongose.Types.ObjectId(req.query.user_id),
        (err, user) => {
            if(!user)
            {
                res.json({
                    result: "failed",
                    data: {},
                    message: `Error is ${err}`
                });
            }
            else{
                res.json({
                    result: "Ok",
                    data: user,
                    message: "Query A Account Successfully"
                })
            }
        }
    );
});

router.post('/insertUser', (req, res, next) => {
    var newUser = new users({
       name: req.body.name,
       email: req.body.email,
       password: req.body.password,
    });

    newUser.save((err, addUser) => {
      if(err)
      {
          res.json({
              result: "failed",
              data: {},
              message: `Error is ${err}`,
          });
      }
      else{
          res.json({
              result: "Ok",
              data: addUser,
              message: "Insert new User Successfully",
          });
      }
    });
});

router.get('/getuserbyidaccount', (req, res, next) => {
    users.aggregate(
        [ { $match : { "accountId": moongose.Types.ObjectId(req.query.account_id) } } ]
    ).exec((err, user) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: user,
                message: "aaaaaaaaaa",
            });
        }
    });


    // users.find(moongose.Types.ObjectId(req.query.account_id),
    //     (user) => {
    //         if(!user)
    //         {
    //             res.json({
    //                 result: "failed",
    //                 data: {},
    //                 message: `Error is ${err}`
    //             });
    //         }
    //         else{
    //             res.json({
    //                 result: "Ok",
    //                 data: user,
    //                 message: "Query Get User By Id Account Successfully"
    //             })
    //         }
    //     }
    // );
});

router.put('/updateuser', (req, res, next) => {
    let conditions = {};
    if(moongose.Types.ObjectId.isValid(req.body.user_id) == true)
    {
        conditions._id = moongose.Types.ObjectId(req.body.user_id);
    }
    else{
        res.json({
            result: "failed",
            data: {},
            message: "You must enter a user id to update",
        });
    }
    let newvalue = {};

    newvalue.name = req.body.name;
    newvalue.email = req.body.email,
    newvalue.password = req.body.password,
    newvalue.accountId = req.body.account_id;
    newvalue.roleId = req.body.role_id;

    const options = {
        new: true,
    }

    users.findOneAndUpdate(conditions, {$set: newvalue}, options, (err, updateUser) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: updateUser,
                message: "Update User successfully",
            });
        }
    });
});


router.delete('/deleteuser', (req, res, next) => {
    users.findOneAndRemove({_id: req.body.user_id}, (err, removeUser) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`,
            });
            return;
        }
        res.json({
            result: "Ok",
            data: removeUser,
            message: 'Delete User Successfully',
        });
    });
});

module.exports = router;