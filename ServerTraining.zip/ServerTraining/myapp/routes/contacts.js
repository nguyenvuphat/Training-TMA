var router = global.router;

var moongose = require('mongoose');
let contacts = require('../models/ContactModel');

router.get('/listContact', (req, res, next) =>{
    contacts.find({}).limit(100).sort({dob: 1}).select({
        fullnameContact: 1,
        lastnameContact: 1,
        email: 1,
        mobile: 1,
        dob: 1,
        accountId: 1,
    }).exec((err, contact) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: contact,
                count: contact.length,
                message: "Query list Contact Successfully"
            })
        }
    });
});

router.get('/getcontactbyid', (req, res, next) => {
    contacts.findById(moongose.Types.ObjectId(req.query.contact_id),
        (err, contact) => {
            if(!contact)
            {
                res.json({
                    result: "failed",
                    data: {},
                    message: `Error is ${err}`
                });
            }
            else{
                res.json({
                    result: "Ok",
                    data: contact,
                    message: "Query A Contact Successfully"
                })
            }
        }
    );
});

router.post('/insertContact', (req, res, next) => {
    var newContact = new contacts({
        fullnameContact: req.body.fullname,
        lastnameContact: req.body.lastname,
        email: req.body.email,
        mobile: req.body.mobile,
        dob: req.body.dob,
    });

    newContact.save((err, addContact) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`,
            });
        }
        else{
            res.json({
                result: "Ok",
                data: addContact,
                message: "Insert new Contact Successfully",
            });
        }
    });
});

router.put('/updatecontact', (req, res, next) => {
    let conditions = {};
    if(moongose.Types.ObjectId.isValid(req.body.contact_id) == true)
    {
        conditions._id = moongose.Types.ObjectId(req.body.contact_id);
    }
    else{
        res.json({
            result: "failed",
            data: {},
            message: "You must enter a contact id to update",
        });
    }
    let newvalue = {};

    newvalue.fullnameContact = req.body.fullname;
    newvalue.lastnameContact = req.body.lastname,
    newvalue.email = req.body.email,
    newvalue.mobile = req.body.mobile;
    newvalue.dob = req.body.dob,
    newvalue.accountId = req.body.account_id;
    const options = {
        new: true,
    }

    contacts.findOneAndUpdate(conditions, {$set: newvalue}, options, (err, updateContact) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`
            });
        }
        else{
            res.json({
                result: "Ok",
                data: updateContact,
                message: "Update Contact successfully",
            });
        }
    });
});

router.delete('/deletecontact', (req, res, next) => {
    contacts.findOneAndRemove({_id: req.body.contact_id}, (err, removeContact) => {
        if(err)
        {
            res.json({
                result: "failed",
                data: {},
                message: `Error is ${err}`,
            });
            return;
        }
        res.json({
            result: "Ok",
            data: removeContact,
            message: 'Delete Contact Successfully',
        });
    });
});

module.exports = router;