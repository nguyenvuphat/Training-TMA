import { Component, OnInit } from '@angular/core';
import {Http} from "@angular/http";

@Component({
  selector: 'app-first',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  name = 'phat'
  selectedAccount = {};
  accounts = [];
  selectedRow(account)
  {
    this.selectedAccount = account;
    console.log(this.selectedAccount);
  }

  // Inject HttpClient into your component or service.
  constructor(private http: Http) {}

  ngOnInit(): void {
    console.log('to here');
    // Make the HTTP request:
    this.http.get('http://localhost:3000/listAccount')
      .toPromise()
      .then(resJson => {
        this.accounts = resJson.json();
        console.log(this.accounts);
      });
  }
}
